<?php

echo "hi";

throw new \Phroses\Exceptions\ExitException;